﻿namespace Log2Excel
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetFileLog = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDevicePrefix = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDeviceSuffix = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLogPath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGetFileLog
            // 
            this.btnGetFileLog.Location = new System.Drawing.Point(751, 8);
            this.btnGetFileLog.Name = "btnGetFileLog";
            this.btnGetFileLog.Size = new System.Drawing.Size(47, 46);
            this.btnGetFileLog.TabIndex = 0;
            this.btnGetFileLog.Text = "...";
            this.btnGetFileLog.UseVisualStyleBackColor = true;
            this.btnGetFileLog.Click += new System.EventHandler(this.btnGetFileLog_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(180, 199);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(565, 46);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Device Prefix";
            // 
            // txtDevicePrefix
            // 
            this.txtDevicePrefix.Location = new System.Drawing.Point(180, 62);
            this.txtDevicePrefix.Name = "txtDevicePrefix";
            this.txtDevicePrefix.Size = new System.Drawing.Size(565, 39);
            this.txtDevicePrefix.TabIndex = 3;
            this.txtDevicePrefix.Text = "VE_24";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(180, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 32);
            this.label2.TabIndex = 4;
            this.label2.Text = "Separate by semicolon";
            // 
            // txtDeviceSuffix
            // 
            this.txtDeviceSuffix.Location = new System.Drawing.Point(180, 112);
            this.txtDeviceSuffix.Name = "txtDeviceSuffix";
            this.txtDeviceSuffix.Size = new System.Drawing.Size(565, 39);
            this.txtDeviceSuffix.TabIndex = 6;
            this.txtDeviceSuffix.Text = "R1;R2;R3;R4;R5;R6";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "Device Suffix";
            // 
            // txtLogPath
            // 
            this.txtLogPath.Location = new System.Drawing.Point(180, 12);
            this.txtLogPath.Name = "txtLogPath";
            this.txtLogPath.ReadOnly = true;
            this.txtLogPath.Size = new System.Drawing.Size(565, 39);
            this.txtLogPath.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 32);
            this.label4.TabIndex = 7;
            this.label4.Text = "Log File Path";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 257);
            this.Controls.Add(this.txtLogPath);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtDeviceSuffix);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDevicePrefix);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnGetFileLog);
            this.Name = "frmMain";
            this.Text = "Log2Excel";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnGetFileLog;
        private Button btnConvert;
        private Label label1;
        private TextBox txtDevicePrefix;
        private Label label2;
        private TextBox txtDeviceSuffix;
        private Label label3;
        private TextBox txtLogPath;
        private Label label4;
    }
}