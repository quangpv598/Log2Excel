﻿using ClosedXML.Excel;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace Log2Excel
{
    public partial class frmMain : Form
    {
        OpenFileDialog fdl = new OpenFileDialog();

        // Các Device Prefix và Suffix sẽ được lưu dưới dạng key trong Dic
        // Mỗi key sẽ chứa một tập các String
        public Dictionary<string, Queue<string>> dicDeviceLog = new Dictionary<string, Queue<string>>();
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnGetFileLog_Click(object sender, EventArgs e)
        {
            fdl.Multiselect = true;
            if (fdl.ShowDialog() == DialogResult.OK)
            {
                txtLogPath.Text = fdl.FileName;
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtLogPath.Text))
            {
                MessageBox.Show("Please select a log file.");
                return;
            }

            //1. Xoá dữ liệu
            dicDeviceLog.Clear();

            //2. Nạp dữ liệu khởi tạo cho từ điển chứa dữ liệu
            var deviceSuffix = txtDeviceSuffix.Text.Split(';');
            foreach (string suffix in deviceSuffix)
            {
                string fullDeviceName = txtDevicePrefix.Text + suffix;
                // Nếu tên thiết bị chưa có trong từ điển, thì thêm vào từ điển
                if (!dicDeviceLog.ContainsKey(fullDeviceName))
                {
                    dicDeviceLog.Add(fullDeviceName, new Queue<string>());
                }
            }

            //3. Duyệt các dòng, ghi dữ liệu vào từ điển
            List<string> lines = new();

            foreach(var file in fdl.FileNames)
            {
                var currentLines = File.ReadAllLines(file);

                lines = lines.Concat(currentLines).ToList();
            }

            for (int i = 0; i < lines.Count; i++)
            {
                string line = lines[i];

                // Kiểm tra nếu dòng chứa lệnh show
                if (line.Replace(" ", "").ToLower().Contains("#show"))
                {
                    // duyệt qua tên các thiết bị đã lưu trước đó
                    foreach (string fullDeviceName in dicDeviceLog.Keys)
                    {
                        // Nếu dòng mà bắt đầu bằng tên thiết bị
                        if (line.StartsWith(fullDeviceName))
                        {
                            var queueString = dicDeviceLog[fullDeviceName];

                            // Thêm dòng hiện tại
                            queueString.Enqueue(line);

                            // Thêm các dòng kết quả của lệnh show cho tới khi gặp lại tên thiết bị

                            i++;
                            line = lines[i];
                            while (dicDeviceLog.Keys.Where(deviceName => line.StartsWith(deviceName)).Count() == 0)
                            {
                                queueString.Enqueue(line);
                                i++;
                                line = lines[i];
                            }

                            // Nếu ngay dòng tiếp theo sau kết quả của lệnh show tiếp đó
                            // mà là 1 lệnh show mới thì tiến hành trừ i đi 1 để đọc lại đoạn show ở trên
                            if (line.Replace(" ", "").ToLower().Contains("#show"))
                            {
                                i--;
                            }

                            break;
                        }
                    }
                }
            }

            //4. Xuất excel từ bộ dữ liệu từ điển
            DataTable dtResult = new DataTable();
            foreach (string columnName in dicDeviceLog.Keys)
            {
                dtResult.Columns.Add(columnName, typeof(string));
            }

            int maxRow = dicDeviceLog.Values.Max(queue => queue.Count);
            for (int i = 0; i < maxRow; i++)
            {
                DataRow drNewRow = dtResult.NewRow();

                foreach (string columnName in dicDeviceLog.Keys)
                {
                    var queue = dicDeviceLog[columnName];
                    if (queue.Count > 0)
                    {
                        drNewRow[columnName] = queue.Dequeue();
                    }
                }

                dtResult.Rows.Add(drNewRow);
            }

            string fileName = txtLogPath.Text.Replace(Path.GetExtension(fdl.FileName), ".xlsx");
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add(dtResult, "Sample Sheet");
                workbook.SaveAs(fileName);
            }

            MessageBox.Show($"Convert Success.\nFile : {fileName}");
        }
    }
}